<?php

/**
 * stub class representing AMQPExchangeException from pecl-amqp
 */
class AMQPExchangeException extends AMQPException
{
}
