<?php

/**
 * stub class representing AMQPChannelException from pecl-amqp
 */
class AMQPChannelException extends AMQPException
{
}
