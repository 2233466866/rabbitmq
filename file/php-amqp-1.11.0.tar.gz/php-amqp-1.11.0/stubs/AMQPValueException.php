<?php

/**
 * stub class representing AMQPExchangeValue from pecl-amqp
 */
class AMQPExchangeValue extends AMQPException
{
}
